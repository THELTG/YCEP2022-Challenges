Libraries required:
pycryptodome

install by doing: pip install pycryptodome
				     OR
				  pip install pycryptodomex

good luck!